import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.sipfresh',
  appName: 'SipFreshNew',
  webDir: 'dist',
  server: {
    // Allow navigation to PayPal domains for payment processing
    allowNavigation: [
      '*.paypal.com',
      '*.paypalobjects.com',
      'https://www.paypal.com',
      'https://www.sandbox.paypal.com'
    ],
    // Uncomment for live reload during development
    // url: 'http://localhost:5173',
    // cleartext: true
  },
  android: {
    // Android-specific configuration
    buildOptions: {
      keystorePath: undefined, // Set path to keystore for release builds
      keystoreAlias: undefined, // Set keystore alias
    }
  }
};

export default config;
