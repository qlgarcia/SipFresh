const s="/assets/SipFreshClear-DEUk0Q68.png";export{s as l};
