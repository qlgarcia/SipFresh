package io.ionic.sipfresh;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
